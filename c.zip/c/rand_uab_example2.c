#include ��stdio.h��
#include "stdlib.h"
#include "randuabs.c"
void main()
{
	int L,a,b;
	int i,flag,j, uab_rand[100];
	L=100;a=-5;b=10;
	flag=randuabs(L,a,b,uab_rand); /*�I�s���*/
	if(!flag)
	{
		printf("ERROR!\n");
		exit(0);
	}
	for(i=0;i<20;i++)
	{
		for(j=0; j<5; j++)
			printf("%3d ",uab_rand[i*10+10]);
		printf("\n");
	}
}