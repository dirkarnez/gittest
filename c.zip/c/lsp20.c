#include ��math.h��
#include ��stdio.h��
#include ��lsq2.c��
main()
{
	int i,j;
	double x[21],y[21],z[21][21],a[6][5],dt[5];
	for(i=0; i<=20; i++) x[i]=0.1*i-1.0;
	for(i=0; i<=20; i++) y[i]=0.1*i-1.0;
	for(i=0; i<=20; i++)
		for(j=0; j<=20; j++)
			z[i][j] = exp(x[i]*x[i]-y[j]*y[j]);
	lsq2(x,y,z,21,21,a,6,5,dt);
	printf("coef matrix is:\n");
	for(i=0; i<6; i++)
	{ 
		for(j=0; j<5; j++)
			printf("%e ",a[i][j]);
		printf("\n");
	}
	for(i=0; i<3; i++)
		printf("dt(%2d)=%e ",i,dt[i]);
}